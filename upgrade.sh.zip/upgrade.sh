#/bin/bash
echo "Check if root / Vérification des permissions root\n"
if [ $EUID -ne 0 ]; then
	sudo $0
	exit
fi

echo "Update and upgrade to avoid problems / Mise à jour des paquets pour eviter les problèmes\n"
apt update;apt full-upgrade -y

echo "Save sources / Sauvegarde des sources\n"
cd /etc
tar czvf apt.tar.gz apt

echo "Change sources / Changement des sources\n"
cd apt
sed -e 's/serena/sonya/g' -i sources.list sources.list.d/official-package-repositories.list

echo "Update and upgrade from new sources / Mise à jour depuis les nouvelles sources\n"
apt update
apt full-upgrade -y

echo "Reboot / Redémarrage\n"
echo "Press Ctrl+C to cancel during the next 10 seconds / Appuyez sur Ctrl+C pour annuler dans les prochaines 10 secondes\n"
sleep 10
reboot